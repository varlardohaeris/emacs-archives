The icons in this subdirectory are taken from https://www.svgrepo.com/
and are licensed under the SVG Repo license: https://www.svgrepo.com/page/licensing
