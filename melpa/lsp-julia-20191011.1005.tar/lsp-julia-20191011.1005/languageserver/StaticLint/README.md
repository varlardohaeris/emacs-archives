# StaticLint

[![Build Status](https://travis-ci.org/julia-vscode/StaticLint.jl.svg?branch=master)](https://travis-ci.org/julia-vscode/StaticLint.jl)
[![Build status](https://ci.appveyor.com/api/projects/status/9excwyfca3s2jpvy/branch/master?svg=true)](https://ci.appveyor.com/project/julia-vscode/staticlint-jl/branch/master)
[![codecov.io](http://codecov.io/github/julia-vscode/StaticLint.jl/coverage.svg?branch=master)](http://codecov.io/github/julia-vscode/StaticLint.jl?branch=master)
Static analysis linter for Julia
