# DocumentFormat

[![Build Status](https://travis-ci.org/julia-vscode/DocumentFormat.jl.svg?branch=master)](https://travis-ci.org/julia-vscode/DocumentFormat.jl)
[![Build status](https://ci.appveyor.com/api/projects/status/o2ym2yk5b3doankw/branch/master?svg=true)](https://ci.appveyor.com/project/julia-vscode/documentformat-jl/branch/master)
[![codecov.io](http://codecov.io/github/julia-vscode/DocumentFormat.jl/coverage.svg?branch=master)](http://codecov.io/github/julia-vscode/DocumentFormat.jl?branch=master)

An auto formatter for Julia.
