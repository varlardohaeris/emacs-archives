<?php

function myFunctionE()
{
}

function myFunctionF()
{
}

// Comment's breaking navgiation?
function myFunctionA()
{
}

function myFunctionB()
{
}

function myFunctionC()
{
}

function myFunctionD()
{
}

/* Does comment's break navgitation? */

function myFunctionG()
{
}

function myFunctionH()
{
}

/** Does comment's break navgitation? **/

function myFunctionI()
{
}

function myFunctionJ()
{
}
