<?php

interface myInterface2 {
    function myFunction2();
}

interface myInterface extends myInterface2  {
    function myFunction();
}
