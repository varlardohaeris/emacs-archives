## TODO

*With current progress estimates:*

* Got imenu items were there are only a namespace, namespace class, or class

* Add to MELPA package archive (50%)
* Wisent LALR parser based on official PHP yacc parser automatically converted grammar (50%)
* mmm-mode support (50%)
* Full integration with Emacs Semantic subsystem (30%)
* Eldoc support (0%)
* Flymake support (0%)
* PSR-2 auto-formatting tool based on lexer tokens (0%)
* Alternative indentation for inline control structures (0%)

[Back to start](../../../)
