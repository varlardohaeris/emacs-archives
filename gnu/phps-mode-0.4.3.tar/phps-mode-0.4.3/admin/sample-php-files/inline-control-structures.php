<?php

if (true)
    echo 'was true 1';
echo 'was here';

if (true)
    echo 'was true 3';
else
    echo 'was false';

$i = 0;
while ($i++ < 10)
    echo ' ' . $i . ' ';
