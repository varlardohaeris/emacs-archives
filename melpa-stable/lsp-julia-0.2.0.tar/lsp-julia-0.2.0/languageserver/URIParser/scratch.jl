hex_string(' ')

escape("t est\n")

u=URI("http://google.com")

sprint(writemime, mime("text/html"), u)
