# Syntax Reference

```@index
Modules = [CSTParser]
Pages   = ["syntax.md"]
```

## Main

```@autodocs
Modules = [CSTParser]
Pages = readdir("../src")
```

## Components

```@autodocs
Modules = [CSTParser]
Pages = readdir("../src/components")
```
