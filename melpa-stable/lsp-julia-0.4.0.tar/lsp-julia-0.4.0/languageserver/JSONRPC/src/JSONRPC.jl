module JSONRPC

import JSON, UUIDs

include("packagedef.jl")

end
