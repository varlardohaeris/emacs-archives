# Syntax Reference

```@index
Modules = [SymbolServer]
Pages   = ["syntax.md"]
```

```@autodocs
Modules = [SymbolServer]
```
