# Revision History for passmm

## 0.2.0 (January 12, 2017)

  * Added prefix argument to `passmm-kill-password` to show the
    password file after killing the password.

  * Fixed all issues identified by `package-lint`.

## 0.1.0 (January 11, 2017)

  * Initial release.
