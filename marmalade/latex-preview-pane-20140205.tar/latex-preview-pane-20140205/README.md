# LaTeX Preview Pane


latex-preview-pane is a minor mode for Emacs that enables you to preview your LaTeX files directly in Emacs. 
It supports PDF previews, your choice of pdflatex or xelatex, and it highlights errors in your LaTeX buffer.
 
Please see the documentation for latex-preview-pane over on EmacsWiki, here: http://www.emacswiki.org/emacs/LaTeXPreviewPane

