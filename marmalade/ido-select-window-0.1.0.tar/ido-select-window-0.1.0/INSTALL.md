# Installation

## Emacs Packages

Simply use `M-x list-packages` and select `ido-select-window`.

## Manual

Place the `lisp/ido-select-window.el` file in your `load-path`.

# Usage

See the README file.
