wedge-ws
========

This provides simple interactions to add (or remove) whitespace between
informal columns in the text, such as tables or aligned comments.

for example, this, with the cursor on the word bar:

    moophlebistre
    cat  dog
    foo  bar
    mef  gog

becomes this:

    moophlebistre
    cat     dog
    foo     bar
    mef     gog

(for clarity, that's three steps)
